from django.db import models

# Create your models here.

class Agent(models.Model):
    nom = models.CharField(max_length=100, null=True)
    genre = models.CharField(max_length=10, null=True)
    grade = models.ForeignKey('Grade', on_delete=models.CASCADE)
    photo = models.ImageField(upload_to="agents/", null=True, blank=True)
    matricule = models.CharField(max_length=30, null=True)
    telephone =models.CharField(max_length=20, null=True)
    mail = models.EmailField(max_length=100, null=True)
    nation = models.CharField(max_length=50, null=True)
    piece = models.CharField(max_length=30, null=True)
    piecenum = models.CharField(max_length=30, null=True)
    adresse = models.TextField(blank=True, null=True)
    daten = models.DateField(null=True)
    lieux = models.CharField(max_length=50, null=True)

class Annonce(models.Model):
    titre = models.CharField(max_length=255)
    photo = models.ImageField(upload_to="annonces/", null=True, blank=True)
    descrption = models.TextField(blank=True, null=True)
    mise_a_jour = models.DateTimeField(auto_now=True)

class Grade(models.Model):
    grade = models.CharField(max_length=100)
    salair = models.FloatField(default=0.0)
    
    def __str__(self):
        return self.grade

class Fonction(models.Model):
    fonction = models.CharField(max_length=100)
    salair = models.FloatField(default=0.0)

class Liaison(models.Model):
    agent = models.ForeignKey('Agent', on_delete=models.CASCADE, null=True, blank=True)
    fonction = models.ForeignKey('Fonction', on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return f"{self.agent.nom}: {self.fonction.salair}"

class Chambre(models.Model):
    nom = models.CharField(max_length=255)
    numero = models.IntegerField(default=0)
    prixJr = models.FloatField(default=0.0)
    prixHr = models.FloatField(default=0.0)
    def __str__(self):
        return f"{self.nom}: {self.prixJr}/Jr {self.prixHr}/h"

class Client(models.Model):
    nom = models.CharField(max_length=255, null=True)
    telephone =models.CharField(max_length=20, null=True)
    mail = models.EmailField(max_length=100, null=True)
    nation = models.CharField(max_length=50, null=True)
    piece = models.CharField(max_length=50, null=True)
    piecenum = models.CharField(max_length=50, null=True)
    chambre = models.ForeignKey('Chambre', on_delete=models.CASCADE)
    entree = models.DateTimeField(auto_now=True)
    sortie = models.DateTimeField(null=True)
    def __str__(self):
        return f"{self.nom}"