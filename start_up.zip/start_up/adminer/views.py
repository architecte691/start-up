from http import client
from threading import local
from django.shortcuts import render
from .models import Agent, Fonction, Grade, Liaison, Chambre, Client
from datetime import date, time, timedelta, datetime as dt
import time as tm
#from rest_framework import viewsets
#from .serializers import ClientSerializer
# Create your views here.
def index(request):
    #Calcul de la masse salariale
    masseSalariale = 0
    agents = Agent.objects.order_by('nom')
    totalAgent = len(agents)
    for agent in agents:
        masseSalariale += agent.grade.salair
        fonctions = Liaison.objects.filter(agent=agent.id)
        for salairs in fonctions:
            masseSalariale += salairs.fonction.salair


    #Calcul des entrées
    annee = dt.today().year
    mois = dt.today().month
    entree = 0
    clients = Client.objects.order_by('nom')
    clientsTable = Client.objects.filter(sortie__gt=dt.today()).order_by('nom')
    totalClient = len(clientsTable)
    for client in clients:
        jour = int((client.sortie - client.entree).days)
        if jour == 0:
            heure = int(str(client.sortie - client.entree).replace(':', ',').split(',')[0])
            entree += (client.chambre.prixHr) * heure
        else:
            entree += (client.chambre.prixJr) * jour
    

    #Calcul de la satisfaction salariale
    satisfaction = int((entree * 100) / masseSalariale)
    return render(request, 'adminer/index.html', locals())

def component(request):
    return render(request, 'adminer/tables.html')

def addclient(request):
    if request.method == 'POST':
        prenom = request.POST['prenom']
        nom = request.POST['nom']
        nom = prenom + ' ' + nom
        phone = request.POST['phone']
        mail = request.POST['mail']
        pays = request.POST['pays']
        piece = request.POST['piece']
        piecenum = request.POST['piecenum']
        chbre = request.POST['chambre']
        datesortie = request.POST['date']
        client, newClient = Client.objects.get_or_create(nom=nom, telephone=phone, mail=mail, nation = pays, piece=piece, piecenum=piecenum, chambre=Chambre.objects.get(id=chbre), sortie=datesortie)
        if newClient:
            ajout = "Le client a été ajouté"
    chambres = Chambre.objects.order_by('numero')
    return render(request, 'adminer/addClient.html', locals())

def addAgent(request):
    if request.method == 'POST':
        nom = request.POST['nom']
        genre = request.POST['genre']
        grade = request.POST['grade']
        photo = request.FILES['img']
        matricule = request.POST['matricule']
        nation = request.POST['nation']
        phone = request.POST['phone']
        mail = request.POST['mail']
        piece = request.POST['piece']
        piecenum = request.POST['piecenum']
        adresse = request.POST['adresse']
        dateN = request.POST['date']
        lieux = request.POST['lieux']
        agent, newAgent = Agent.objects.get_or_create(nom=nom, genre=genre, photo=photo, matricule=matricule, grade=Grade.objects.get(id=grade), telephone=phone, mail=mail, nation=nation, piece=piece, piecenum=piecenum, adresse=adresse, daten=dateN, lieux=lieux)
        if newAgent:
            ajout = "L'agent a été ajouté"
    grades = Grade.objects.order_by('grade')
    return render(request, 'adminer/addAgent.html', locals())

def agentList(request):
    agents = Agent.objects.order_by('nom')
    totalAgent = len(agents)
    return render(request, 'adminer/agentListe.html', locals())

def agentDetail(request, id):
    agent = Agent.objects.get(id=id)
    agent.nom = str(agent.nom).capitalize()
    #fonctions, errorget = Liaison.objects.get_or_404(agent=agent)
    return render(request, 'adminer/users-profile.html', locals())

def clientsList(request):
    clientsTable = Client.objects.filter(sortie__gt=dt.today()).order_by('nom')
    return render(request, 'adminer/clientsListe.html', locals())

def gradeAndFonction(request):
    grades = Grade.objects.order_by('grade')
    fonctions = Fonction.objects.order_by('fonction')
    return render(request,'adminer/grade.html', locals())

def addGrade(request):
    if request.method == 'POST':
        nomination = request.POST['nomination']
        salair = request.POST['salair']
        classeur = request.POST['classeur']
        if str(classeur) == 'grade':
            avoir, ajout = Grade.objects.get_or_create(grade=nomination, salair=salair)
            if ajout:
                ajout = 'Paramètre ajouté !'
            else:
                ajout = ' '
        elif str(classeur) == 'fonction':
            avoir, ajout = Fonction.objects.get_or_create(fonction=nomination, salair=salair)
            if ajout:
                ajout = 'Paramètre ajouté !'
            else:
                ajout = ' '
    return render(request, 'adminer/add-grade.html', locals())

def chambres(request):
    now = dt.today()
    chambres = Chambre.objects.order_by('numero')
    clients = Client.objects.filter(sortie__gt=now).order_by('nom')
    tableChambre = []
    for client in clients:
        for chambre in chambres:
            if client.chambre.numero == chambre.numero:
                tableChambre.extend({'chambres':{'chambre':chambre.nom, 'numero':chambre.numero, 'etat':'Occupé'}})
    chambres = {'chambres':tableChambre}
    return render(request, 'adminer/chambres.html', locals())

# class restAPI(viewsets.ModelViewSet):
#     queryset = Client.objects.all()
#     serializerclass = ClientSerializer