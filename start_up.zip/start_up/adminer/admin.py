from django.contrib import admin
from .models import Agent, Annonce, Fonction, Grade, Liaison, Chambre, Client

# Register your models here.
admin.site.register(Agent)
admin.site.register(Annonce)
admin.site.register(Client)
admin.site.register(Fonction)
admin.site.register(Grade)
admin.site.register(Liaison)
admin.site.register(Chambre)