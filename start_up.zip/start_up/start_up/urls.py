"""start_up URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from adminer.views import index, addGrade, component, addclient, addAgent, clientsList, chambres, agentList, agentDetail, gradeAndFonction
# from adminer.urls import router as rout_api
# from rest_framework import routers

#router = routers.DefaultRouter()
#router.register('',rout_api.register)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index, name='home'),
    path('tables/', component, name='table'),
    path('add-client/', addclient, name='client'),
    path('add-agent/', addAgent, name="addAgent"),
    path('clients-list/', clientsList, name="liste-clients"),
    path('liste-agents', agentList, name="listeAgent"),
    path('agent-detail/<int:id>', agentDetail, name="agent-detail"),
    path('grade-and-fonction/', gradeAndFonction, name="grade"),
    path('add-grade-or-fonction/', addGrade, name="add-grade"),
    path('chambres/', chambres, name="chambre"),
    #path('api', include(router.urls, namespace='api')),
]
